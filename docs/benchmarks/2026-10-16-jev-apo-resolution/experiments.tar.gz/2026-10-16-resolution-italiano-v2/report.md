# Esperimento APO per Jev

Esperimento: `2026-10-16-dbffa216-2641-4a15-b463-cc9d8c52b084`. Stato: **searching**.

Modello: `typesafe-ai/jev-1.14.0`; optimizer: `deepseek/deepseek-v4.1-flash`.

Dataset sintetico con etichette note per costruzione. Nessuna validazione umana o misura di accuratezza in produzione.

Split: 108 training / 36 validation / 36 test; seed 20261018; 2 ripetizioni. Le varianti della stessa fonte e i quasi duplicati rilevati rimangono nello stesso split.

Budget contabilizzato: $0.032236, 661108 token, 474 chiamate; costi non disponibili per 1 chiamate (riserva prudenziale inclusa). Limiti: $0.5, 3000000 token, 3000 chiamate. Costi senza valore provider stimati dal catalogo salvato; non sono fatture.

Arresto: non congelato. Il test è accessibile solo dopo frozen.json; i risultati non sono restituiti all'optimizer.

| Task | Macro-F1 validation iniziale → selezionato | Macro-F1 test iniziale → selezionato | Δ test | IC 95% Δ | Esito |
|---|---|---|---|---|---|
| resolution | 65.90% → 100.00% | non eseguito | — | — | incompleto |

## resolution

Prompt: 195 → 1718 caratteri, 36 → 325 token stimati. Arresto: non disponibile.

## Interpretazione e riproducibilità

La metrica primaria è macro-F1 alle soglie applicative originali (0,8). Le choice sotto soglia sono astensioni, non risposte corrette. Il bootstrap è appaiato per fonte: ripetizioni e varianti non aumentano artificialmente la numerosità indipendente. Gli intervalli sono esplorativi su un campione piccolo, senza correzione per confronti multipli. La somiglianza dei template sintetici può sovrastimare la trasferibilità. Nessun risultato prova un miglioramento sui contenuti reali del Brain.

Una selezione su validation non equivale a raccomandazione di adozione: il report richiede miglioramento nel test, intervallo inferiore positivo e assenza delle regressioni vietate per indicare candidate_for_review. Non viene effettuata alcuna promozione o scrittura al Brain. Per un ulteriore ciclo dopo il test usare nuove fonti indipendenti.

Dataset SHA-256: `1833412c90a24d174fce320c4d8270ac9b943610663d9dd274fb137bb0b2c7ef`. Motore SHA-256: `3f7e9958ec9a8b49cc84c1155e92065eac289c383fbd7f2dd423042e451cec7d`.

manifest.json conserva dataset, split, prompt originali, modelli, prezzi e configurazione; candidates/ conserva le proposte; calls/ richieste identificate da hash, risposte e spesa; predictions/ tutte le predizioni; selection/ le decisioni di selezione; frozen.json la scelta precedente al test; final/ le metriche finali. report.json include matrici di confusione, risultati per classe/lingua/categoria e provenienza della supervisione.
