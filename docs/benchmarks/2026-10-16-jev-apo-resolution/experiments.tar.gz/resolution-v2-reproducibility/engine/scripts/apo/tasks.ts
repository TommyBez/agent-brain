import {
  DECISION_POLICY,
  SCREENING_THRESHOLD,
} from "../../lib/maintenance/consolidator/decision-policy";
import {
  BASELINE_PROFILE,
  type PromptTask,
} from "../../lib/maintenance/consolidator/prompts";
import {
  preparationQuestions,
  screeningQuestions,
} from "../../lib/maintenance/consolidator/questions";
import type {
  Answer,
  EvaluationRequest,
} from "../../lib/maintenance/consolidator/types";
import type { Example } from "./types";

export const TASKS: Record<
  PromptTask,
  {
    description: string;
    labels: string[];
    threshold: number;
    invariant: string;
  }
> = {
  duplicate: {
    description:
      "Detect substantial repeated factual knowledge within one page or across two pages, before any editing decision.",
    labels: ["false", "true"],
    threshold: SCREENING_THRESHOLD,
    invariant:
      "Shared topics alone are not duplicates. Flag existence without assuming any fact may be deleted.",
  },
  conflict: {
    description:
      "Detect apparently incompatible claims about the same entity/scope requiring correction or clarification.",
    labels: ["false", "true"],
    threshold: SCREENING_THRESHOLD,
    invariant:
      "Detection does not require a supported resolution. Already explicit different scopes/periods are compatible.",
  },
  link: {
    description:
      "Detect an evidenced useful directed relationship missing from the source page links.",
    labels: ["false", "true"],
    threshold: SCREENING_THRESHOLD,
    invariant:
      "Respect direction, entity identity and existing edges; topical similarity is insufficient.",
  },
  residue: {
    description:
      "Detect removable consolidator diaries or agent-invented human follow-ups.",
    labels: ["false", "true"],
    threshold: SCREENING_THRESHOLD,
    invariant:
      "Preserve original user requests, subject knowledge and genuine uncertainty. Agent activity is not subject knowledge.",
  },
  actionable: {
    description:
      "Decide whether consolidation of the two supplied target passages would meaningfully improve their pages.",
    labels: ["false", "true"],
    threshold: DECISION_POLICY.analyst.yes,
    invariant:
      "Preserve distinct facts/sources and necessary local context. Complementary facts, citation-only repetition, useful summaries and cosmetic rewrites are not actionable duplication. Do not prejudge a hypothetical draft.",
  },
  resolution: {
    description:
      "Choose which intervention on conflicting target passages is established by the supplied sources.",
    labels: ["a", "b", "temporal", "scope", "insufficient", "none"],
    threshold: DECISION_POLICY.analyst.choiceProbability,
    invariant:
      "Only supplied source evidence can authorize a correction; page timestamps and confident wording are not factual authority. Keep all six fixed criteria. Unsupported interventions must not be authorized.",
  },
};

/** The same builders as production; dataset labels/IDs/proofs never enter state. */
export function requestFor(
  example: Example,
  prompt: string,
): EvaluationRequest {
  const profile = {
    id: "offline",
    prompts: { ...BASELINE_PROFILE.prompts, [example.task]: prompt },
  };
  let question =
    example.task === "actionable"
      ? preparationQuestions("duplicate", profile).actionable
      : example.task === "resolution"
        ? preparationQuestions("conflict", profile).resolution
        : screeningQuestions(example.pair, profile)[
            example.task === "link" ? `link_${example.direction}` : example.task
          ];
  if (!question)
    throw new Error(`Task incompatible with example: ${example.id}`);
  if (example.direct) {
    if (!["actionable", "resolution"].includes(example.task))
      throw new Error("Invalid direct preparation");
    const premise =
      example.task === "actionable"
        ? "target[0] and target[1] repeat factual information"
        : "target[0] and target[1] contain apparently incompatible claims about the same entity and scope";
    question = {
      ...question,
      instructions: `Assuming ${premise}, answer the following intervention question independently: ${question.instructions}`,
    };
  }
  return { state: example.state, questions: { decision: question } };
}

export function classify(task: PromptTask, answer: Answer) {
  if (answer.type === "boolean")
    return String(answer.probability >= TASKS[task].threshold);
  return answer.probabilities[answer.choice] >= TASKS[task].threshold
    ? answer.choice
    : "abstain";
}
