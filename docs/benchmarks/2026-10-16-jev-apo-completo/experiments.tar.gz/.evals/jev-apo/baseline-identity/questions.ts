import type { LinkType } from "/Users/tommaso/personal-projects/agent-brain/lib/brain/types";
import {
  EVIDENCE_RULES,
  type PromptProfile,
  renderPrompt,
  resolvePromptProfile,
} from "/Users/tommaso/personal-projects/agent-brain/lib/maintenance/consolidator/prompts";
import type { Question } from "/Users/tommaso/personal-projects/agent-brain/lib/maintenance/consolidator/types";

const RULES = EVIDENCE_RULES;

export function booleanQuestion(instructions: string): Question {
  return { type: "boolean", instructions: instructions + RULES };
}

export function choiceQuestion(
  instructions: string,
  criteria: Record<string, string>,
): Question {
  return { type: "choice", instructions: instructions + RULES, criteria };
}

export function screeningQuestions(
  pair: boolean,
  profile: PromptProfile = resolvePromptProfile(),
): Record<string, Question> {
  const scope = pair ? "across pages[0] and pages[1]" : "within pages[0]";
  const questions: Record<string, Question> = {
    duplicate: booleanQuestion(renderPrompt("duplicate", { scope }, profile)),
    conflict: booleanQuestion(renderPrompt("conflict", { scope }, profile)),
  };
  if (pair) {
    questions.link_ab = booleanQuestion(
      renderPrompt("link", { source: "0", target: "1" }, profile),
    );
    questions.link_ba = booleanQuestion(
      renderPrompt("link", { source: "1", target: "0" }, profile),
    );
  } else
    questions.residue = booleanQuestion(renderPrompt("residue", {}, profile));
  return questions;
}

export function preparationQuestions(
  kind: "duplicate" | "conflict" | "residue",
  profile: PromptProfile = resolvePromptProfile(),
): Record<string, Question> {
  if (kind === "residue")
    return {
      removable: booleanQuestion(
        "Can target[0] be removed in its entirety without losing any distinct subject knowledge, original request, factual uncertainty, useful citation or necessary local context? Only consolidator activity and agent-added human follow-up may be removed.",
      ),
    };
  if (kind === "duplicate")
    return {
      destination: choiceQuestion(
        "Where should the shared information in target[0] and target[1] be retained, considering their complete containing pages? Choose the appropriate canonical home, not the more recent technical timestamp. Select equivalent when both locations are equally suitable; code will break the tie deterministically.",
        {
          a: "Retain shared information at target[0].",
          b: "Retain shared information at target[1].",
          equivalent: "Both locations are equally suitable canonical homes.",
          none: "Neither location is a supported destination for consolidation.",
        },
      ),
      actionable: booleanQuestion(renderPrompt("actionable", {}, profile)),
    };
  return {
    resolution: choiceQuestion(renderPrompt("resolution", {}, profile), {
      a: "Evidence establishes target[0]'s claim and explicitly supports correcting the incompatible claim in target[1].",
      b: "Evidence establishes target[1]'s claim and explicitly supports correcting the incompatible claim in target[0].",
      temporal:
        "Evidence documents successive factual states; clarify their actual periods while preserving history.",
      scope:
        "Evidence establishes different scopes; clarify the distinction without discarding either fact.",
      insufficient:
        "An intervention needs a specifically referenced source not supplied here.",
      none: "No supported useful correction or clarification can be made from the evidence.",
    }),
  };
}

/** Evaluate the only eligible pair and its speculative intervention together. */
export function pairPreparationQuestions(
  kind: "duplicate" | "conflict",
): Record<string, Question> {
  const premise =
    kind === "duplicate"
      ? "target[0] and target[1] repeat factual information"
      : "target[0] and target[1] contain apparently incompatible claims about the same entity and scope";
  return {
    counterpart: booleanQuestion(
      `Do ${premise}? Judge these exact two passages in their complete page context. Shared topic alone is insufficient. Identify the relationship only; a supported correction or deletion is not required.`,
    ),
    ...Object.fromEntries(
      Object.entries(preparationQuestions(kind)).map(([id, question]) => [
        id,
        {
          ...question,
          instructions: `Assuming ${premise}, answer the following intervention question independently: ${question.instructions}`,
        },
      ]),
    ),
  };
}

export const RELATION_MEANINGS: Record<LinkType, string> = {
  works_at: "the source person works at the target organization",
  owns: "the source entity owns the target entity or resource",
  part_of: "the source entity is a constituent part of the target entity",
  relates_to:
    "a concrete specific relationship connects source to target and is useful for navigation; shared topic alone is insufficient",
  decided_in:
    "the source decision or subject was decided in the target meeting, article or recorded context",
  references:
    "the source content explicitly cites or refers to the target entity or document",
  depends_on:
    "the source entity or activity depends on the target entity, resource or activity",
  supersedes:
    "the source replaces the target, supported by substantive succession evidence, not page update time",
  collaborates_with: "the source entity collaborates with the target entity",
};
