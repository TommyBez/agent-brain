import assert from "node:assert/strict";
import {writeFile} from "node:fs/promises";
import * as oldQuestions from "./questions";
import {verifyChangeSet as oldVerify} from "./verifier";
import * as current from "../../../lib/maintenance/consolidator/questions";
import {verifyChangeSet} from "../../../lib/maintenance/consolidator/verifier";
import {BASELINE_PROFILE} from "../../../lib/maintenance/consolidator/prompts";
import type {EvaluationRequest, Evaluate} from "../../../lib/maintenance/consolidator/types";
import {verificationFixtures} from "../../../scripts/jev-missing-dataset";
import {fingerprint} from "../../../lib/canonical-json";

async function main() {
for (const pair of [false,true]) assert.deepEqual(current.screeningQuestions(pair,BASELINE_PROFILE),oldQuestions.screeningQuestions(pair,BASELINE_PROFILE));
for (const kind of ["duplicate","conflict","residue"] as const) assert.deepEqual(current.preparationQuestions(kind,BASELINE_PROFILE),oldQuestions.preparationQuestions(kind,BASELINE_PROFILE));
for (const kind of ["duplicate","conflict"] as const) assert.deepEqual(current.pairPreparationQuestions(kind,BASELINE_PROFILE),oldQuestions.pairPreparationQuestions(kind));
const comparisons=[];
for (const fixture of verificationFixtures(0)) {
  const capture = async (verify: typeof verifyChangeSet) => {
    const requests: EvaluationRequest[]=[];
    const evaluate: Evaluate=async request=>{
      requests.push(request);
      return {model:"identity",answers:Object.fromEntries(Object.keys(request.questions).map(id=>[id,{type:"boolean" as const,probability:1}])),inputTokens:0,outputTokens:0};
    };
    const result=await verify(fixture.snapshot,fixture.changeSet,evaluate,BASELINE_PROFILE);
    return {requests,result};
  };
  const before=await capture(oldVerify),after=await capture(verifyChangeSet);
  assert.deepEqual(after,before);
  comparisons.push({category:fixture.category,requests:before.requests.length,hash:fingerprint(before)});
}
await writeFile(new URL("result.json",import.meta.url),JSON.stringify({baselineRequestIdentity:true,verificationFixtures:comparisons},null,2)+"\n");
console.log(`Baseline identical for all preparation/screening questions and ${comparisons.length} complete verification flows.`);

}
main().catch(e=>{console.error(e);process.exitCode=1;});
