/** Safe diagnostics survive Workflow error serialization without storing prompts or SQL. */
export type FailureDiagnostic = {
  category: "jev" | "editor" | "gateway" | "database" | "internal";
  code: string;
  retryable: boolean;
};

export class EditorResponseError extends Error {
  readonly name = "EditorResponseError";

  constructor(
    readonly reason:
      | "invalid_choices"
      | "truncated_output"
      | "refused_output"
      | "unexpected_finish_reason"
      | "missing_content"
      | "invalid_json"
      | "invalid_schema",
    readonly usage: {
      prompt_tokens?: number;
      completion_tokens?: number;
      reasoning_tokens?: number;
    },
    readonly generationId?: string,
  ) {
    super(
      `Invalid consolidation draft: ${reason.replaceAll("_", " ").replace("json", "JSON")}`,
    );
  }
}

export function failureDiagnostic(error: unknown): FailureDiagnostic {
  const message =
    typeof error === "string"
      ? error
      : error !== null && typeof error === "object" && "message" in error
        ? String(error.message)
        : "";
  const encoded = message.match(
    /Consolidation failure \[(jev|editor|gateway|database|internal):([A-Za-z0-9_]+):(retry|fatal)\]/,
  );
  if (encoded)
    return {
      category: encoded[1] as FailureDiagnostic["category"],
      code: encoded[2],
      retryable: encoded[3] === "retry",
    };
  if (!(error instanceof Error)) {
    if (error !== null && typeof error === "object" && "cause" in error)
      return failureDiagnostic(error.cause);
    return { category: "internal", code: "unknown", retryable: false };
  }
  if (error.name === "JevResponseError" && "reason" in error)
    return { category: "jev", code: String(error.reason), retryable: false };
  if (error instanceof EditorResponseError)
    return { category: "editor", code: error.reason, retryable: false };
  if (error.name === "GatewayRequestError" && "status" in error)
    return {
      category: "gateway",
      code: "reason" in error ? String(error.reason) : "transport",
      retryable: "retryable" in error && error.retryable === true,
    };
  const code = "code" in error ? error.code : undefined;
  if (
    typeof code === "string" &&
    /^(?:[0-9A-Z]{5}|ECONNRESET|ECONNREFUSED|ETIMEDOUT|EPIPE)$/.test(code)
  )
    return {
      category: "database",
      code,
      retryable:
        /^08/.test(code) ||
        [
          "40001",
          "40P01",
          "53300",
          "57P01",
          "57P02",
          "57P03",
          "ECONNRESET",
          "ECONNREFUSED",
          "ETIMEDOUT",
          "EPIPE",
        ].includes(code),
    };
  if (error.cause) return failureDiagnostic(error.cause);
  return {
    category: "internal",
    code: ["TypeError", "SyntaxError", "RangeError"].includes(error.name)
      ? error.name
      : "unknown",
    retryable: false,
  };
}

export function failureMessage(diagnostic: FailureDiagnostic): string {
  return `Consolidation failure [${diagnostic.category}:${diagnostic.code}:${diagnostic.retryable ? "retry" : "fatal"}]`;
}
