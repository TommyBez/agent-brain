# Esperimento APO per Jev

Esperimento: `2026-10-16-7237a6b1-0cca-4659-8ec5-3e5fe84f571d`. Stato: **complete**.

Modello: `typesafe-ai/jev-1.14.0`; optimizer: `deepseek/deepseek-v4.1-flash`.

Dataset sintetico con etichette note per costruzione. Nessuna validazione umana o misura di accuratezza in produzione.

Split: 1596 training / 532 validation / 532 test; seed 20261019; 2 ripetizioni. Le varianti della stessa fonte e i quasi duplicati rilevati rimangono nello stesso split.

Budget contabilizzato: $0.582589, 11672825 token, 8046 chiamate; costi non disponibili per 0 chiamate (riserva prudenziale inclusa). Limiti: $1.75, 24000000 token, 20000 chiamate. Costi senza valore provider stimati dal catalogo salvato; non sono fatture.

Arresto: search_complete. Il test è accessibile solo dopo frozen.json; i risultati non sono restituiti all'optimizer.

| Task | Macro-F1 validation iniziale → selezionato | Macro-F1 test iniziale → selezionato | Δ test | IC 95% Δ | Esito |
|---|---|---|---|---|---|
| actionable | 63.82% → 100.00% | 54.29% → 96.61% | 42.32 pp | [36.18, 46.53] pp | candidate_for_review |
| verification | 85.54% → 85.54% | 84.65% → 84.65% | 0.00 pp | [0.00, 0.00] pp | retain_baseline |
| localize_duplicate | 100.00% → 100.00% | 93.73% → 93.73% | 0.00 pp | [0.00, 0.00] pp | retain_baseline |
| localize_conflict | 100.00% → 100.00% | 100.00% → 100.00% | 0.00 pp | [0.00, 0.00] pp | retain_baseline |
| localize_residue | 100.00% → 100.00% | 100.00% → 100.00% | 0.00 pp | [0.00, 0.00] pp | retain_baseline |
| partner_duplicate | 96.43% → 96.43% | 100.00% → 100.00% | 0.00 pp | [0.00, 0.00] pp | retain_baseline |
| partner_conflict | 98.33% → 98.33% | 92.86% → 92.86% | 0.00 pp | [0.00, 0.00] pp | retain_baseline |
| counterpart_duplicate | 100.00% → 100.00% | 96.87% → 96.87% | 0.00 pp | [0.00, 0.00] pp | retain_baseline |
| counterpart_conflict | 87.30% → 87.30% | 93.73% → 93.73% | 0.00 pp | [0.00, 0.00] pp | retain_baseline |
| destination | 96.43% → 100.00% | 94.76% → 100.00% | 5.24 pp | [0.00, 15.00] pp | retain_baseline |
| removable | 95.15% → 100.00% | 81.07% → 100.00% | 18.93 pp | [4.85, 42.65] pp | candidate_for_review |
| relation | 83.36% → 100.00% | 73.33% → 100.00% | 26.67 pp | [23.33, 31.43] pp | candidate_for_review |
| conflict | 100.00% → 100.00% | 96.87% → 96.87% | 0.00 pp | [0.00, 0.00] pp | retain_baseline |
| duplicate | 73.33% → 100.00% | 80.57% → 100.00% | 19.43 pp | [6.27, 26.67] pp | candidate_for_review |
| residue | 48.57% → 100.00% | 48.57% → 100.00% | 51.43 pp | [51.43, 51.43] pp | candidate_for_review |

## actionable

Prompt: 792 → 2699 caratteri, 130 → 467 token stimati. Arresto: no_training_errors.

Training: 192 → 192 predizioni; errori tecnici 0 → 0. Gli errori tecnici sono esclusi dal feedback all'optimizer ma restano nel denominatore delle metriche e nel registro dei costi.

Test: 32 esempi in 4 fonti indipendenti per costruzione. Accuracy 68.75% → 96.88%. Errori tecnici 0 → 0; astensioni 0 → 0.

Latenza media 323 → 323 ms, p95 395 → 416 ms. Token input medi 926.8 → 1280.8; costo medio $0.0000389 → $0.0000538.

| Classe | Precision prima → dopo | Recall prima → dopo |
|---|---|---|
| false | 66.67% → 95.24% | 100.00% → 100.00% |
| true | 100.00% → 100.00% | 16.67% → 91.67% |

| Lingua | Accuracy prima → dopo | Macro-F1 prima → dopo |
|---|---|---|
| it | 68.75% → 96.88% | 54.29% → 96.61% |

Errori corretti: missing-it-v1-00-actionable-cross-page-repetition, missing-it-v1-00-actionable-overlap-with-details, missing-it-v1-13-actionable-cross-page-repetition, missing-it-v1-13-actionable-overlap-with-details, missing-it-v1-14-actionable-cross-page-repetition, missing-it-v1-14-actionable-overlap-with-details, missing-it-v1-19-actionable-cross-page-repetition, missing-it-v1-19-actionable-overlap-with-details, missing-it-v1-00-actionable-same-page-repetition, missing-it-v1-13-actionable-same-page-repetition.

Nuove regressioni: nessuna.

## verification

Prompt: 0 → 0 caratteri, 0 → 0 token stimati. Arresto: patience.

Training: 1440 → 1440 predizioni; errori tecnici 0 → 0. Gli errori tecnici sono esclusi dal feedback all'optimizer ma restano nel denominatore delle metriche e nel registro dei costi.

Test: 240 esempi in 4 fonti indipendenti per costruzione. Accuracy 85.00% → 85.00%. Errori tecnici 0 → 0; astensioni 0 → 0.

Latenza media 313 → 313 ms, p95 423 → 423 ms. Token input medi 1996.2 → 1996.2; costo medio $0.0000838 → $0.0000838.

| Classe | Precision prima → dopo | Recall prima → dopo |
|---|---|---|
| false | 76.92% → 76.92% | 100.00% → 100.00% |
| true | 100.00% → 100.00% | 70.00% → 70.00% |

| Lingua | Accuracy prima → dopo | Macro-F1 prima → dopo |
|---|---|---|
| it | 85.00% → 85.00% | 84.65% → 84.65% |

Errori corretti: nessuno.

Nuove regressioni: nessuna.

## localize_duplicate

Prompt: 326 → 326 caratteri, 59 → 59 token stimati. Arresto: no_training_errors.

Training: 96 → 96 predizioni; errori tecnici 0 → 0. Gli errori tecnici sono esclusi dal feedback all'optimizer ma restano nel denominatore delle metriche e nel registro dei costi.

Test: 16 esempi in 4 fonti indipendenti per costruzione. Accuracy 93.75% → 93.75%. Errori tecnici 0 → 0; astensioni 0 → 0.

Latenza media 302 → 302 ms, p95 405 → 405 ms. Token input medi 706.6 → 706.6; costo medio $0.0000297 → $0.0000297.

| Classe | Precision prima → dopo | Recall prima → dopo |
|---|---|---|
| false | 88.89% → 88.89% | 100.00% → 100.00% |
| true | 100.00% → 100.00% | 87.50% → 87.50% |

| Lingua | Accuracy prima → dopo | Macro-F1 prima → dopo |
|---|---|---|
| it | 93.75% → 93.75% | 93.73% → 93.73% |

Errori corretti: nessuno.

Nuove regressioni: nessuna.

## localize_conflict

Prompt: 331 → 331 caratteri, 62 → 62 token stimati. Arresto: patience.

Training: 96 → 96 predizioni; errori tecnici 0 → 0. Gli errori tecnici sono esclusi dal feedback all'optimizer ma restano nel denominatore delle metriche e nel registro dei costi.

Test: 16 esempi in 4 fonti indipendenti per costruzione. Accuracy 100.00% → 100.00%. Errori tecnici 0 → 0; astensioni 0 → 0.

Latenza media 344 → 344 ms, p95 594 → 594 ms. Token input medi 711.3 → 711.3; costo medio $0.0000299 → $0.0000299.

| Classe | Precision prima → dopo | Recall prima → dopo |
|---|---|---|
| false | 100.00% → 100.00% | 100.00% → 100.00% |
| true | 100.00% → 100.00% | 100.00% → 100.00% |

| Lingua | Accuracy prima → dopo | Macro-F1 prima → dopo |
|---|---|---|
| it | 100.00% → 100.00% | 100.00% → 100.00% |

Errori corretti: nessuno.

Nuove regressioni: nessuna.

## localize_residue

Prompt: 314 → 314 caratteri, 60 → 60 token stimati. Arresto: no_training_errors.

Training: 144 → 144 predizioni; errori tecnici 0 → 0. Gli errori tecnici sono esclusi dal feedback all'optimizer ma restano nel denominatore delle metriche e nel registro dei costi.

Test: 24 esempi in 4 fonti indipendenti per costruzione. Accuracy 100.00% → 100.00%. Errori tecnici 0 → 0; astensioni 0 → 0.

Latenza media 342 → 342 ms, p95 643 → 643 ms. Token input medi 660.3 → 660.3; costo medio $0.0000277 → $0.0000277.

| Classe | Precision prima → dopo | Recall prima → dopo |
|---|---|---|
| false | 100.00% → 100.00% | 100.00% → 100.00% |
| true | 100.00% → 100.00% | 100.00% → 100.00% |

| Lingua | Accuracy prima → dopo | Macro-F1 prima → dopo |
|---|---|---|
| it | 100.00% → 100.00% | 100.00% → 100.00% |

Errori corretti: nessuno.

Nuove regressioni: nessuna.

## partner_duplicate

Prompt: 308 → 308 caratteri, 54 → 54 token stimati. Arresto: no_training_errors.

Training: 96 → 96 predizioni; errori tecnici 0 → 0. Gli errori tecnici sono esclusi dal feedback all'optimizer ma restano nel denominatore delle metriche e nel registro dei costi.

Test: 16 esempi in 4 fonti indipendenti per costruzione. Accuracy 100.00% → 100.00%. Errori tecnici 0 → 0; astensioni 0 → 0.

Latenza media 297 → 297 ms, p95 369 → 369 ms. Token input medi 965.6 → 965.6; costo medio $0.0000406 → $0.0000406.

| Classe | Precision prima → dopo | Recall prima → dopo |
|---|---|---|
| none | 100.00% → 100.00% | 100.00% → 100.00% |
| p0 | 100.00% → 100.00% | 100.00% → 100.00% |
| p1 | 100.00% → 100.00% | 100.00% → 100.00% |
| p2 | 100.00% → 100.00% | 100.00% → 100.00% |

| Lingua | Accuracy prima → dopo | Macro-F1 prima → dopo |
|---|---|---|
| it | 100.00% → 100.00% | 100.00% → 100.00% |

Errori corretti: nessuno.

Nuove regressioni: nessuna.

## partner_conflict

Prompt: 350 → 350 caratteri, 62 → 62 token stimati. Arresto: patience.

Training: 96 → 96 predizioni; errori tecnici 0 → 0. Gli errori tecnici sono esclusi dal feedback all'optimizer ma restano nel denominatore delle metriche e nel registro dei costi.

Test: 16 esempi in 4 fonti indipendenti per costruzione. Accuracy 87.50% → 87.50%. Errori tecnici 0 → 0; astensioni 4 → 4.

Latenza media 309 → 309 ms, p95 336 → 336 ms. Token input medi 972.5 → 972.5; costo medio $0.0000408 → $0.0000408.

| Classe | Precision prima → dopo | Recall prima → dopo |
|---|---|---|
| none | 100.00% → 100.00% | 100.00% → 100.00% |
| p0 | 100.00% → 100.00% | 100.00% → 100.00% |
| p1 | 100.00% → 100.00% | 75.00% → 75.00% |
| p2 | 100.00% → 100.00% | 75.00% → 75.00% |

| Lingua | Accuracy prima → dopo | Macro-F1 prima → dopo |
|---|---|---|
| it | 87.50% → 87.50% | 92.86% → 92.86% |

Errori corretti: nessuno.

Nuove regressioni: nessuna.

## counterpart_duplicate

Prompt: 237 → 237 caratteri, 45 → 45 token stimati. Arresto: no_training_errors.

Training: 96 → 96 predizioni; errori tecnici 0 → 0. Gli errori tecnici sono esclusi dal feedback all'optimizer ma restano nel denominatore delle metriche e nel registro dei costi.

Test: 16 esempi in 4 fonti indipendenti per costruzione. Accuracy 96.88% → 96.88%. Errori tecnici 0 → 0; astensioni 0 → 0.

Latenza media 314 → 314 ms, p95 437 → 437 ms. Token input medi 840.9 → 840.9; costo medio $0.0000353 → $0.0000353.

| Classe | Precision prima → dopo | Recall prima → dopo |
|---|---|---|
| false | 100.00% → 100.00% | 93.75% → 93.75% |
| true | 94.12% → 94.12% | 100.00% → 100.00% |

| Lingua | Accuracy prima → dopo | Macro-F1 prima → dopo |
|---|---|---|
| it | 96.88% → 96.88% | 96.87% → 96.87% |

Errori corretti: nessuno.

Nuove regressioni: nessuna.

## counterpart_conflict

Prompt: 281 → 281 caratteri, 52 → 52 token stimati. Arresto: patience.

Training: 96 → 96 predizioni; errori tecnici 0 → 0. Gli errori tecnici sono esclusi dal feedback all'optimizer ma restano nel denominatore delle metriche e nel registro dei costi.

Test: 16 esempi in 4 fonti indipendenti per costruzione. Accuracy 93.75% → 93.75%. Errori tecnici 0 → 0; astensioni 0 → 0.

Latenza media 301 → 301 ms, p95 404 → 404 ms. Token input medi 842.8 → 842.8; costo medio $0.0000354 → $0.0000354.

| Classe | Precision prima → dopo | Recall prima → dopo |
|---|---|---|
| false | 88.89% → 88.89% | 100.00% → 100.00% |
| true | 100.00% → 100.00% | 87.50% → 87.50% |

| Lingua | Accuracy prima → dopo | Macro-F1 prima → dopo |
|---|---|---|
| it | 93.75% → 93.75% | 93.73% → 93.73% |

Errori corretti: nessuno.

Nuove regressioni: nessuna.

## destination

Prompt: 303 → 1478 caratteri, 54 → 274 token stimati. Arresto: no_training_errors.

Training: 96 → 96 predizioni; errori tecnici 0 → 0. Gli errori tecnici sono esclusi dal feedback all'optimizer ma restano nel denominatore delle metriche e nel registro dei costi.

Test: 16 esempi in 4 fonti indipendenti per costruzione. Accuracy 90.63% → 100.00%. Errori tecnici 0 → 0; astensioni 3 → 0.

Latenza media 336 → 330 ms, p95 468 → 456 ms. Token input medi 1043.0 → 1266.0; costo medio $0.0000438 → $0.0000532.

| Classe | Precision prima → dopo | Recall prima → dopo |
|---|---|---|
| a | 100.00% → 100.00% | 100.00% → 100.00% |
| b | 100.00% → 100.00% | 100.00% → 100.00% |
| equivalent | 100.00% → 100.00% | 87.50% → 100.00% |
| none | 100.00% → 100.00% | 75.00% → 100.00% |

| Lingua | Accuracy prima → dopo | Macro-F1 prima → dopo |
|---|---|---|
| it | 90.63% → 100.00% | 94.76% → 100.00% |

Errori corretti: missing-it-v1-00-destination-home-none, missing-it-v1-14-destination-home-equivalent.

Nuove regressioni: nessuna.

## removable

Prompt: 245 → 1353 caratteri, 44 → 253 token stimati. Arresto: no_training_errors.

Training: 144 → 144 predizioni; errori tecnici 0 → 0. Gli errori tecnici sono esclusi dal feedback all'optimizer ma restano nel denominatore delle metriche e nel registro dei costi.

Test: 24 esempi in 4 fonti indipendenti per costruzione. Accuracy 85.42% → 100.00%. Errori tecnici 0 → 0; astensioni 0 → 0.

Latenza media 285 → 343 ms, p95 322 → 461 ms. Token input medi 675.8 → 889.8; costo medio $0.0000284 → $0.0000374.

| Classe | Precision prima → dopo | Recall prima → dopo |
|---|---|---|
| false | 82.05% → 100.00% | 100.00% → 100.00% |
| true | 100.00% → 100.00% | 56.25% → 100.00% |

| Lingua | Accuracy prima → dopo | Macro-F1 prima → dopo |
|---|---|---|
| it | 85.42% → 100.00% | 81.07% → 100.00% |

Errori corretti: missing-it-v1-14-removable-invented-followup, missing-it-v1-19-removable-agent-diary, missing-it-v1-19-removable-invented-followup, missing-it-v1-00-removable-invented-followup.

Nuove regressioni: nessuna.

## relation

Prompt: 239 → 1984 caratteri, 41 → 348 token stimati. Arresto: no_training_errors.

Training: 264 → 264 predizioni; errori tecnici 0 → 0. Gli errori tecnici sono esclusi dal feedback all'optimizer ma restano nel denominatore delle metriche e nel registro dei costi.

Test: 44 esempi in 4 fonti indipendenti per costruzione. Accuracy 73.86% → 100.00%. Errori tecnici 0 → 0; astensioni 23 → 0.

Latenza media 300 → 297 ms, p95 351 → 343 ms. Token input medi 856.7 → 1175.7; costo medio $0.0000360 → $0.0000494.

| Classe | Precision prima → dopo | Recall prima → dopo |
|---|---|---|
| none | 100.00% → 100.00% | 100.00% → 100.00% |
| works_at | 100.00% → 100.00% | 100.00% → 100.00% |
| owns | 0.00% → 100.00% | 0.00% → 100.00% |
| part_of | 100.00% → 100.00% | 100.00% → 100.00% |
| relates_to | 100.00% → 100.00% | 25.00% → 100.00% |
| decided_in | 100.00% → 100.00% | 100.00% → 100.00% |
| references | 100.00% → 100.00% | 87.50% → 100.00% |
| depends_on | 100.00% → 100.00% | 100.00% → 100.00% |
| supersedes | 100.00% → 100.00% | 100.00% → 100.00% |
| collaborates_with | 0.00% → 100.00% | 0.00% → 100.00% |

| Lingua | Accuracy prima → dopo | Macro-F1 prima → dopo |
|---|---|---|
| it | 73.86% → 100.00% | 73.33% → 100.00% |

Errori corretti: missing-it-v1-00-relation-typed-owns, missing-it-v1-00-relation-typed-relates_to, missing-it-v1-00-relation-typed-collaborates_with, missing-it-v1-13-relation-typed-owns, missing-it-v1-13-relation-typed-relates_to, missing-it-v1-13-relation-typed-references, missing-it-v1-13-relation-typed-collaborates_with, missing-it-v1-14-relation-typed-owns, missing-it-v1-14-relation-typed-collaborates_with, missing-it-v1-19-relation-typed-owns, missing-it-v1-19-relation-typed-relates_to, missing-it-v1-19-relation-typed-collaborates_with, missing-it-v1-14-relation-typed-relates_to.

Nuove regressioni: nessuna.

## conflict

Prompt: 207 → 207 caratteri, 36 → 36 token stimati. Arresto: no_training_errors.

Training: 96 → 96 predizioni; errori tecnici 0 → 0. Gli errori tecnici sono esclusi dal feedback all'optimizer ma restano nel denominatore delle metriche e nel registro dei costi.

Test: 16 esempi in 4 fonti indipendenti per costruzione. Accuracy 96.88% → 96.88%. Errori tecnici 0 → 0; astensioni 0 → 0.

Latenza media 383 → 383 ms, p95 464 → 464 ms. Token input medi 600.4 → 600.4; costo medio $0.0000252 → $0.0000252.

| Classe | Precision prima → dopo | Recall prima → dopo |
|---|---|---|
| false | 94.12% → 94.12% | 100.00% → 100.00% |
| true | 100.00% → 100.00% | 93.75% → 93.75% |

| Lingua | Accuracy prima → dopo | Macro-F1 prima → dopo |
|---|---|---|
| it | 96.88% → 96.88% | 96.87% → 96.87% |

Errori corretti: nessuno.

Nuove regressioni: nessuna.

## duplicate

Prompt: 180 → 804 caratteri, 30 → 137 token stimati. Arresto: no_training_errors.

Training: 96 → 96 predizioni; errori tecnici 0 → 0. Gli errori tecnici sono esclusi dal feedback all'optimizer ma restano nel denominatore delle metriche e nel registro dei costi.

Test: 16 esempi in 4 fonti indipendenti per costruzione. Accuracy 81.25% → 100.00%. Errori tecnici 0 → 0; astensioni 0 → 0.

Latenza media 352 → 289 ms, p95 480 → 332 ms. Token input medi 596.1 → 704.1; costo medio $0.0000250 → $0.0000296.

| Classe | Precision prima → dopo | Recall prima → dopo |
|---|---|---|
| false | 100.00% → 100.00% | 62.50% → 100.00% |
| true | 72.73% → 100.00% | 100.00% → 100.00% |

| Lingua | Accuracy prima → dopo | Macro-F1 prima → dopo |
|---|---|---|
| it | 81.25% → 100.00% | 80.57% → 100.00% |

Errori corretti: missing-it-v1-00-duplicate-different-entity, missing-it-v1-13-duplicate-different-entity, missing-it-v1-19-duplicate-different-entity.

Nuove regressioni: nessuna.

## residue

Prompt: 229 → 981 caratteri, 40 → 180 token stimati. Arresto: no_training_errors.

Training: 144 → 144 predizioni; errori tecnici 0 → 0. Gli errori tecnici sono esclusi dal feedback all'optimizer ma restano nel denominatore delle metriche e nel registro dei costi.

Test: 24 esempi in 4 fonti indipendenti per costruzione. Accuracy 50.00% → 100.00%. Errori tecnici 0 → 0; astensioni 0 → 0.

Latenza media 538 → 343 ms, p95 717 → 536 ms. Token input medi 514.1 → 657.1; costo medio $0.0000216 → $0.0000276.

| Classe | Precision prima → dopo | Recall prima → dopo |
|---|---|---|
| false | 40.00% → 100.00% | 100.00% → 100.00% |
| true | 100.00% → 100.00% | 25.00% → 100.00% |

| Lingua | Accuracy prima → dopo | Macro-F1 prima → dopo |
|---|---|---|
| it | 50.00% → 100.00% | 48.57% → 100.00% |

Errori corretti: missing-it-v1-00-residue-agent-diary, missing-it-v1-00-residue-mixed-diary-and-fact, missing-it-v1-00-residue-unique-factual-source, missing-it-v1-13-residue-agent-diary, missing-it-v1-13-residue-mixed-diary-and-fact, missing-it-v1-13-residue-unique-factual-source, missing-it-v1-14-residue-agent-diary, missing-it-v1-14-residue-mixed-diary-and-fact, missing-it-v1-14-residue-unique-factual-source, missing-it-v1-19-residue-agent-diary, missing-it-v1-19-residue-mixed-diary-and-fact, missing-it-v1-19-residue-unique-factual-source.

Nuove regressioni: nessuna.

## Interpretazione e riproducibilità

La metrica primaria è macro-F1 alle soglie applicative originali: 0,8 per screening e preparazione, 0,7 per localizzazione; per il verificatore 0,8 su obiettivo e condotta, 0,65 sui singoli requisiti di integrità. Le choice sotto soglia sono astensioni, non risposte corrette. Il bootstrap è appaiato per fonte: ripetizioni e varianti non aumentano artificialmente la numerosità indipendente. Gli intervalli sono esplorativi su un campione piccolo, senza correzione per confronti multipli. La somiglianza dei template sintetici può sovrastimare la trasferibilità. Nessun risultato prova un miglioramento sui contenuti reali del Brain.

Una selezione su validation non equivale a raccomandazione di adozione: il report richiede miglioramento nel test, intervallo inferiore positivo e assenza delle regressioni vietate per indicare candidate_for_review. Non viene effettuata alcuna promozione o scrittura al Brain. Per un ulteriore ciclo dopo il test usare nuove fonti indipendenti.

Dataset SHA-256: `320694e4c4e817d17df22b09cad7495976824defe8c882b7ca20596e9c14322a`. Motore SHA-256: `238b03c60fdc9d00a17f2ec7b6c0aef222d43b38eca20ba3426b0629a4874db0`.

manifest.json conserva dataset, split, prompt originali, modelli, prezzi e configurazione; candidates/ conserva le proposte; calls/ richieste identificate da hash, risposte e spesa; predictions/ tutte le predizioni; selection/ le decisioni di selezione; frozen.json la scelta precedente al test; final/ le metriche finali. report.json include matrici di confusione, risultati per classe/lingua/categoria e provenienza della supervisione.
