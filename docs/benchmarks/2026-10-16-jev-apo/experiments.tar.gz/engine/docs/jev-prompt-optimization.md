# Ottimizzazione offline dei prompt di Jev

La CLI `pnpm apo` applica Automated Prompt Optimization alle decisioni del consolidatore. Misura prima i prompt originali, presenta all'optimizer solo errori del training set, confronta i candidati su validation e congela la selezione prima del test finale. Non modifica i pesi, le soglie del consolidatore, le pagine del Brain o la configurazione di produzione.

L'applicazione usa contenuti italiani: il generatore e il contratto del dataset accettano **solo italiano**. Le istruzioni baseline conservano la lingua e il testo già presenti nel codice. Nessun input viene tradotto prima dell'inferenza.

## Analisi del progetto e perimetro

Il consolidatore usa `typesafe-ai/jev-1.14.0` via `POST /v1/evaluate` e DeepSeek V4.1 Flash per le modifiche testuali. Le risposte Jev sono probabilità booleane oppure distribuzioni su opzioni fisse. L'endpoint esistente, il parser rigoroso, Zod, il tokenizer, `tsx` e `node:test` vengono riutilizzati; non sono richiesti AI SDK, Python o DSPy.

Sono stati individuati screening, localizzazione, preparazione degli interventi, scelta del tipo di relazione e verifica delle bozze. Questa prima pipeline ottimizza sei task separati già costruiti in `lib/maintenance/consolidator/questions.ts`:

| Task | Input | Esito e criterio |
|---|---|---|
| `duplicate` | Una o due pagine complete | Esiste ripetizione fattuale sostanziale; non basta un tema comune. |
| `conflict` | Una o due pagine complete | Esistono affermazioni incompatibili sullo stesso soggetto/ambito; la soluzione non deve essere già disponibile. |
| `link` | Due pagine e link esistenti, nelle due direzioni | È documentata una relazione utile e diretta che manca nei link della sorgente. |
| `residue` | Una pagina completa | Sono presenti diari del consolidatore o richieste umane inventate dall'agente; richieste originali e incertezza reale vanno preservate. |
| `actionable` | Pagine e due passaggi target | Consolidare migliora realmente la conoscenza; non sono sufficienti una riscrittura cosmetica, fatti complementari o un riepilogo utile. |
| `resolution` | Pagine, due target ed eventuali fonti riprodotte | Una delle sei opzioni `a`, `b`, `temporal`, `scope`, `insufficient`, `none`, secondo l'evidenza effettivamente fornita. |

Localizzazione, scelta della destinazione canonica, tipizzazione della relazione e verifica delle bozze mantengono le istruzioni originali. Non vengono presentati come task ottimizzati. Il filtro `residue` e il giudizio di rimovibilità di un passaggio sono decisioni distinte; qui viene ottimizzato il primo.

Le fixture e i test esistenti forniscono il contratto e i casi limite. Non esiste nel checkout corrente un dataset di produzione etichettato utilizzabile per questi sei task: gli esiti delle scritture e le valutazioni storiche dello stesso Jev non costituiscono ground truth indipendente. L'esperimento iniziale usa quindi fonti fittizie note per costruzione, senza accedere al database o ai contenuti privati.

## Dataset e supervisione

Il generatore produce 630 esempi da 30 famiglie di fonti italiane: cinque task con 90 esempi ciascuno e risoluzione con 180. Ogni esempio conserva ID, gruppo sorgente, task, lingua, categoria, stato originale, contesto della domanda, etichetta, metodo, versione, provenienza, stato di validazione e motivazione. Il contratto verifica anche che i target siano porzioni esatte delle pagine.

Le etichette sintetiche sono dichiarate `constructed`, non validate da esseri umani. Le trasformazioni comprendono parafrasi, contraddizioni, informazioni complementari, periodi espliciti, link già presenti, diari, richieste originali, riepiloghi utili e fonti presenti/assenti. Il generatore è deterministico e conserva tutto il materiale nel sorgente; non usa un LLM per inventare risposte corrette.

Lo split 60/20/20 usa seed e gruppi di fonte. Copie esatte e quasi duplicati rilevati con Jaccard dei trigrammi (soglia 0,85) vengono uniti prima dello split. La validazione impone la presenza di tutte le classi in ogni split. Questo controllo non garantisce assenza di ogni similarità semantica: le strutture sintetiche rimangono un limite di trasferibilità.

`SupervisionStrategy` consente inoltre etichette deterministiche, umane o derivate da esiti reali già documentati, oppure etichettatura LLM e consenso tra modelli distinti. Gli input del judge non includono etichetta attesa, prompt candidato o versione. Rubrica e versione rimangono fisse. Il consenso usa voto di maggioranza e registra accordo, motivazioni, ambiguità e confidenza dichiarata dai modelli; pareggi, bassa confidenza e ambiguità sono marcati incerti. L'accordo non equivale a correttezza. Etichette incerte o con accordo/confidenza inferiori a 0,8 sono escluse dall'ottimizzazione ma conservate negli artefatti. Il dataset può importare etichette ibride con provenienza esplicita; non viene dichiarata una verifica indipendente dove non esiste.

## Protocollo e selezione

La metrica primaria è macro-F1. Il significato delle etichette e le soglie restano fissi: probabilità booleana almeno 0,8; per le choice, probabilità dell'opzione scelta almeno 0,8, altrimenti astensione. Errori di trasporto/parsing sono fallimenti tecnici, non giudizi negativi.

Il report include accuracy, precision/recall/F1 per classe, matrice di confusione, astensioni, falsi positivi nei task binari, categorie, ripetibilità, token, costi e latenza. L'average precision usa le probabilità booleane originali, raggruppando i pareggi; non viene calcolata da semplici etichette.

Ogni task ha al massimo cinque candidati e si arresta dopo due tentativi senza miglioramento o in assenza di errori di training. La selezione richiede almeno 0,01 di macro-F1 in più, nessun aumento dei falsi positivi binari, nessuna regressione oltre 0,05 nelle categorie o nel recall delle classi, nessun errore tecnico e p95 entro 10 secondi. Il miglioramento deve superare la variabilità osservata tra ripetizioni. Un bootstrap appaiato per fonte deve escludere regressioni negative; una raccomandazione finale richiede anche un limite inferiore strettamente positivo nel test. Sono intervalli esplorativi su pochi gruppi, senza correzione per confronti multipli.

Il meta-prompt richiede modifiche minime e generali. Un campione bilanciato per categoria di errore evita che una categoria monopolizzi il feedback. Il candidato deve preservare placeholder e clausole protette, rispettare 4.000 caratteri e 1.200 token stimati ed evitare identificativi, nomi delle fonti e scorciatoie sulle etichette. Il suffisso di sicurezza e i criteri delle choice non sono modificabili dall'optimizer. I controlli sintattici non costituiscono una prova completa di equivalenza semantica: validation e test restano necessari.

La configurazione iniziale usa due ripetizioni, massimo 6.000 chiamate, quattro milioni di token e due dollari. Il 30% dei limiti è riservato al confronto finale. Ogni chiamata fisica viene registrata con una riserva prudenziale prima dell'invio; esiti incerti mantengono la riserva e non vengono ritentati automaticamente. Il costo restituito dal provider ha precedenza sulla stima del catalogo. Prezzi, modelli e parametri sono salvati nel manifest. Il seed controlla split e bootstrap: Jev non riceve parametri di sampling non supportati e non viene promesso determinismo del servizio.

## Comandi

È sufficiente `AI_GATEWAY_API_KEY` nell'ambiente o in `.env.local`. Le credenziali non vengono copiate negli artefatti. Prima della preparazione salvare il catalogo corrente:

```sh
mkdir -p .evals/jev-apo
curl -fsSL https://ai-gateway.vercel.sh/v1/models -o .evals/jev-apo/catalog.json
pnpm apo generate --out .evals/jev-apo/dataset.json
pnpm apo validate --dataset .evals/jev-apo/dataset.json
pnpm apo supervision --dataset .evals/jev-apo/dataset.json
pnpm apo prepare --out .evals/jev-apo/run-01 \
  --dataset .evals/jev-apo/dataset.json \
  --catalog .evals/jev-apo/catalog.json
pnpm apo baseline --run .evals/jev-apo/run-01
pnpm apo run --run .evals/jev-apo/run-01
pnpm apo report --run .evals/jev-apo/run-01
pnpm apo export --run .evals/jev-apo/run-01 --out .evals/jev-apo/candidate.json
```

`run` include baseline, ricerca e test; `baseline` separato è opzionale e i risultati già acquisiti vengono riutilizzati. `resume --run …` continua dagli artefatti senza ripetere chiamate riuscite. `final --run …` richiede una selezione già congelata. SIGINT interrompe l'esecuzione; la ripresa recupera un lock solo se il processo precedente non esiste più. Un'altra esecuzione contemporanea sullo stesso esperimento viene rifiutata. Gli esperimenti esistenti non vengono sovrascritti; modificare dataset, configurazione o sorgente del motore richiede una nuova preparazione.

Per valutare un prompt specifico prima del congelamento:

```sh
pnpm apo evaluate --run .evals/jev-apo/run-01 --task residue --prompt /tmp/residue.txt
```

Questo comando usa esclusivamente validation. Il test non è un'opzione esplorativa. Dopo averlo consultato, qualsiasi ulteriore sviluppo richiede nuove fonti indipendenti.

Per la modalità economica, aggiungere `--smoke` a `prepare`: seleziona cinque famiglie e dichiara il risultato non definitivo. `--config config.json` può modificare i campi definiti da `configSchema`, per esempio:

```json
{
  "tasks": ["actionable", "resolution"],
  "iterations": 5,
  "repeats": 2,
  "patience": 2,
  "maxDollars": 2,
  "maxTokens": 4000000,
  "optimizerModel": "deepseek/deepseek-v4.1-flash"
}
```

Il modello deve esistere nel catalogo salvato. Per etichettatura con LLM configurare `judgeModels` con uno o più modelli distinti da Jev e optimizer, presenti nel catalogo. Eseguire poi `label --run … --strategy judge|consensus --out nuovo-dataset.json` prima del congelamento e preparare un nuovo esperimento con il dataset risultante. `label` con `deterministic`, `human` o `outcome` valida e conserva etichette documentate del metodo indicato: non converte automaticamente dati non etichettati in ground truth. `generate` costruisce autonomamente esempi e relative etichette sintetiche.

Il generatore separato `scripts/jev-link-dataset.ts` costruisce un secondo corpus di 200 casi italiani, da venti nuove famiglie, per ampliare la copertura delle relazioni. Include riferimenti, rapporti di lavoro, proprietà e dipendenze, anche quando la prova compare soltanto nella pagina destinazione; i negativi comprendono collegamenti già presenti, tema comune e omonimie esplicitamente distinte. Le fonti del primo esperimento non vengono riutilizzate. Si prepara un nuovo esperimento con `tasks: ["link"]` e il normale protocollo bloccato:

```sh
node --import tsx scripts/jev-link-dataset.ts .evals/jev-apo/relazioni-italiane.json
pnpm apo prepare --out .evals/jev-apo/run-relazioni \
  --dataset .evals/jev-apo/relazioni-italiane.json \
  --config config-relazioni.json --catalog .evals/jev-apo/catalog.json
pnpm apo run --run .evals/jev-apo/run-relazioni
```

Questo secondo corpus nasce dalla revisione semantica del candidato, non dagli errori del primo test. Anche un candidato con metriche positive va trattenuto se restringe il significato del task: un riferimento nella sorgente non è un requisito universale per tutte le relazioni supportate dal Brain. La revisione del contratto accompagna la raccomandazione statistica e precede ogni attivazione.

## Artefatti e promozione

Ogni directory contiene manifest con checksum, dataset e split, baseline immutabile, sistema dell'optimizer, metadati dei modelli, risposte e consumo delle chiamate, tutte le predizioni, proposte e motivazioni, decisioni di selezione, selezione congelata, risultati finali e report Markdown/JSON. `.evals/` è ignorata da Git; per condividere un esperimento conservare esplicitamente questi file. Per dati reali occorre prepararne una versione minimizzata e autorizzata prima di passarla al Gateway.

L'esportazione produce il prompt selezionato su validation, anche quando il test finale raccomanda di conservare la baseline. Leggere quindi sempre `report.md`. Per rendere un candidato disponibile al codice, senza attivarlo:

```sh
pnpm apo register --profile .evals/jev-apo/candidate.json
```

La registrazione aggiunge una versione a `lib/maintenance/consolidator/prompt-profiles.json`; non sovrascrive versioni esistenti. L'attivazione richiede una modifica esplicita di `JEV_PROMPT_PROFILE` all'ID esportato e il normale rilascio. Il valore predefinito rimane `baseline`; per rollback impostare `JEV_PROMPT_PROFILE=baseline`. Non cambiare il profilo durante un workflow in corso: completare o interrompere quel run prima del rilascio.

L'identità del profilo e l'hash dei suoi prompt entrano nelle chiavi di task/piani, evitando il riuso di decisioni ottenute con istruzioni diverse. Ogni valutazione registra inoltre `promptVersion`, hash delle domande effettivamente renderizzate. Le normali tracce conservano probabilità, consumi, errori ed esiti; dopo una promozione vanno confrontati anche l'incidenza di interventi respinti/incerti e i difetti del verificatore per questa versione. Il benchmark offline non sostituisce tale osservazione.

## Verifica e riferimenti

```sh
node --import tsx --test tests/jev-apo.test.ts
pnpm test
pnpm lint
pnpm typecheck
```

I test ordinari usano fixture e adapter iniettati; includono un ciclo completo con supervisione sintetica esplicita. Non effettuano chiamate pagate. L'esperimento reale è separato e richiede l'esecuzione della CLI.

Il metodo segue la guida fornita dall'utente e il ciclo descritto da [Parallel](https://parallel.ai/blog/are-all-system-one-models-created-equal), aggiungendo una separazione training/validation/test esplicita. Il contratto HTTP è documentato da [AI Gateway](https://vercel.com/docs/ai-gateway/modalities/decision); la progettazione delle domande segue [TypeSafe Noul](https://docs.typesafe.ai/primitives/noul) e [State](https://docs.typesafe.ai/concepts/state). Modelli e prezzi sono verificati sul catalogo live durante la preparazione, non dedotti da quei riferimenti.
